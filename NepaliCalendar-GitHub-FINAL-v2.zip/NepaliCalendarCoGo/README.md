# Nepali Calendar — Code on the Go edition

A modern English-only Nepali Calendar Android app by **Rajeshwor Maharjan**.

## Designed for Code on the Go (CoGo)

This project is configured for the current CoGo 26.37 toolchain:
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- compileSdk / targetSdk 35
- Java/JDK supplied by CoGo

CoGo supplies its own Android SDK/JDK/Gradle environment, so this project intentionally does **not** include a machine-specific `local.properties` file or a Gradle wrapper.

## Features

- Animated splash: “Nepali Calendar by Rajeshwor Maharjan”
- Modern deep-green / lime-green interface
- BS monthly calendar
- Live festivals and public holidays
- BS ↔ AD date converter
- Personal events saved on the device
- Home, Calendar, Festivals, Convert and More sections
- Internet permission for live calendar data

## Build in CoGo

1. Extract this ZIP to a normal folder on your phone.
2. Open **Code on the Go**.
3. Open/import the extracted folder as an existing Gradle Android project.
4. Allow CoGo to initialize/sync the project and install any requested SDK components.
5. Run the Gradle task:
   `:app:assembleDebug`
6. The APK is generated at:
   `app/build/outputs/apk/debug/app-debug.apk`

### Important

This package is intended for **CoGo 26.37 (current stable as of September 14, 2026)**. CoGo has announced a 64-bit toolchain migration around September 15, 2026 that changes to AGP 9.3.1 / Kotlin 2.3.21 / Gradle 9.6.1. If your installed CoGo has already moved to that new toolchain and this project fails to sync, send me the build-error screenshot and I will make a migration build for that version.

The project is a functional first release. It has not been compiled in this environment because an Android SDK/build toolchain is not available here.
