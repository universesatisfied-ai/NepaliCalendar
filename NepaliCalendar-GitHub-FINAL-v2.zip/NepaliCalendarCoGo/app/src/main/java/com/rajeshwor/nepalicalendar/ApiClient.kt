package com.rajeshwor.nepalicalendar

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {
    private const val CAL_BASE = "https://api-nepalicalendar.leapcell.app"
    private const val DATE_BASE = "https://npdates.org"

    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000; c.readTimeout = 15000; c.requestMethod = "GET"
        c.setRequestProperty("Accept", "application/json")
        return c.inputStream.bufferedReader().use { it.readText() }.also { c.disconnect() }
    }

    fun today(): JSONObject = JSONObject(get("$DATE_BASE/api/today"))
    fun month(year: Int, month: Int): JSONObject = JSONObject(get("$CAL_BASE/calendar/$year/$month"))
    fun year(year: Int): JSONObject = JSONObject(get("$CAL_BASE/calendar/$year"))
    fun bsToAd(y: Int,m: Int,d: Int): JSONObject = JSONObject(get("$DATE_BASE/api/convert/bs-to-ad?year=$y&month=$m&day=$d"))
    fun adToBs(y: Int,m: Int,d: Int): JSONObject = JSONObject(get("$DATE_BASE/api/convert/ad-to-bs?year=$y&month=$m&day=$d"))

    fun parseDays(payload: JSONObject): List<DayInfo> {
        val a = payload.optJSONArray("days") ?: JSONArray()
        return buildList { for (i in 0 until a.length()) { val o=a.getJSONObject(i); add(DayInfo(o.optInt("d"),o.optString("n"),o.optString("e"),o.optString("t"),o.optString("f"),o.optBoolean("h"))) } }
    }
}

data class DayInfo(val bsDay:Int,val nepaliNumber:String,val adDay:String,val tithi:String,val festival:String,val holiday:Boolean)
