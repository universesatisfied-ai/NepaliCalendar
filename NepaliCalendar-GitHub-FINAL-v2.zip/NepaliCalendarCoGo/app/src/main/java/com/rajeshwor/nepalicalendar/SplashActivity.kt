package com.rajeshwor.nepalicalendar

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.animation.AnimationUtils
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class SplashActivity : Activity() {
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
  window.statusBarColor=ContextCompat.getColor(this,R.color.deep_green); window.navigationBarColor=ContextCompat.getColor(this,R.color.deep_green)
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(32,32,32,32);setBackgroundColor(ContextCompat.getColor(context,R.color.deep_green))}
  val icon=TextView(this).apply{text="▣";textSize=56f;setTextColor(ContextCompat.getColor(context,R.color.lime));gravity=Gravity.CENTER}
  val title=TextView(this).apply{text="Nepali Calendar";textSize=30f;setTextColor(ContextCompat.getColor(context,R.color.white));gravity=Gravity.CENTER}
  val sub=TextView(this).apply{text="by Rajeshwor Maharjan";textSize=15f;setTextColor(ContextCompat.getColor(context,R.color.lime));gravity=Gravity.CENTER}
  box.addView(icon);box.addView(title);box.addView(sub);setContentView(box)
  val anim=AnimationUtils.loadAnimation(this,R.anim.fade_slide);box.startAnimation(anim)
  window.decorView.postDelayed({startActivity(Intent(this,MainActivity::class.java));finish()},1300)
 }
}
