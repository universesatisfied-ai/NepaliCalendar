package com.rajeshwor.nepalicalendar

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
 private val bg by lazy { ContextCompat.getColor(this,R.color.deep_green) }; private val surface by lazy { ContextCompat.getColor(this,R.color.surface) }; private val lime by lazy { ContextCompat.getColor(this,R.color.lime) }; private val white by lazy { ContextCompat.getColor(this,R.color.white) }; private val muted by lazy { ContextCompat.getColor(this,R.color.muted) }
 private val executor=Executors.newFixedThreadPool(3); private lateinit var content:LinearLayout; private lateinit var bottom:BottomNavigationView
 private var todayBs=Triple(2083,6,1); private var calYear=2083; private var calMonth=6
 private val months=listOf("Baisakh","Jestha","Ashadh","Shrawan","Bhadra","Ashwin","Kartik","Mangsir","Poush","Magh","Falgun","Chaitra")
 private var currentDays=emptyList<DayInfo>()

 override fun onCreate(b:Bundle?){super.onCreate(b);window.statusBarColor=bg;window.navigationBarColor=bg; buildShell(); loadToday()}
 private fun buildShell(){
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
  content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,12,18,8)}
  val scroll=ScrollView(this).apply{addView(content)}; root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
  bottom=BottomNavigationView(this).apply{inflateMenu(R.menu.bottom_nav);setBackgroundColor(surface);itemIconTintList=null;setOnItemSelectedListener{ when(it.itemId){R.id.nav_home->{showHome();true};R.id.nav_calendar->{showCalendar();true};R.id.nav_festivals->{showFestivals();true};R.id.nav_converter->{showConverter();true};else->{showMore();true}} }}
  root.addView(bottom,LinearLayout.LayoutParams(-1,72));setContentView(root);showHome()
 }
 private fun label(text:String,size:Float=14f,color:Int=white,bold:Boolean=false)=TextView(this).apply{this.text=text;textSize=size;setTextColor(color);if(bold)typeface=Typeface.DEFAULT_BOLD;setPadding(0,4,0,4)}
 private fun card():MaterialCardView=MaterialCardView(this).apply{setCardBackgroundColor(surface);radius=24f;strokeWidth=0;elevation=0f}
 private fun row():LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
 private fun title(t:String,sub:String?=null){content.removeAllViews();content.addView(label(t,28f,white,true));sub?.let{content.addView(label(it,14f,muted))};content.addView(Space(this),LinearLayout.LayoutParams(1,12))}
 private fun loadToday(){ executor.execute{try{val j=ApiClient.today();val b=j.getJSONObject("bs");todayBs=Triple(b.getInt("year"),b.getInt("month"),b.getInt("day"));calYear=todayBs.first;calMonth=todayBs.second;runOnUiThread{showHome()}}catch(e:Exception){runOnUiThread{showHome();toast("Could not reach calendar service")}}} }
 private fun showHome(){title("Nepali Calendar","Your modern Bikram Sambat companion");
  val c=card();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,20,20,20)}
  box.addView(label("TODAY",12f,lime,true));box.addView(label("${todayBs.third} ${months[todayBs.second-1]} ${todayBs.first}",32f,white,true));box.addView(label(SimpleDateFormat("EEEE, MMMM d, yyyy",Locale.US).format(Date()),15f,muted));
  val actions=row();actions.addView(MaterialButton(this).apply{text="Open Calendar";setOnClickListener{showCalendar()}},LinearLayout.LayoutParams(0,52,1f));actions.addView(Space(this),LinearLayout.LayoutParams(10,1));actions.addView(MaterialButton(this).apply{text="Convert";setOnClickListener{showConverter()}},LinearLayout.LayoutParams(0,52,1f));box.addView(actions);c.addView(box);content.addView(c)
  content.addView(label("Quick view",20f,white,true));val info=card();val ib=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,16,18,16)};ib.addView(label("Loading today's tithi and events…",15f,muted));info.addView(ib);content.addView(info)
  executor.execute{try{val m=ApiClient.month(calYear,calMonth);val day=ApiClient.parseDays(m).firstOrNull{it.bsDay==todayBs.third};runOnUiThread{ib.removeAllViews();ib.addView(label(day?.tithi?.ifBlank{"Tithi not provided"}?:"Tithi not provided",17f,white,true));if(day?.festival?.isNotBlank()==true)ib.addView(label(day.festival,14f,lime));if(day?.holiday==true)ib.addView(label("Public holiday",13f,ContextCompat.getColor(this,R.color.red),true))}}catch(_:Exception){}} }
 private fun showCalendar(){title("Calendar","Bikram Sambat • ${calYear}");val nav=row();val prev=MaterialButton(this).apply{text="‹";setOnClickListener{changeMonth(-1)}};val mid=label("${months[calMonth-1]} $calYear",20f,white,true).apply{gravity=Gravity.CENTER};val next=MaterialButton(this).apply{text="›";setOnClickListener{changeMonth(1)}};nav.addView(prev,LinearLayout.LayoutParams(60,52));nav.addView(mid,LinearLayout.LayoutParams(0,52,1f));nav.addView(next,LinearLayout.LayoutParams(60,52));content.addView(nav);val grid=GridLayout(this).apply{columnCount=7;rowCount=7};content.addView(grid);grid.addView(label("Sun",12f,muted,true),cellParams());grid.addView(label("Mon",12f,muted,true),cellParams());grid.addView(label("Tue",12f,muted,true),cellParams());grid.addView(label("Wed",12f,muted,true),cellParams());grid.addView(label("Thu",12f,muted,true),cellParams());grid.addView(label("Fri",12f,muted,true),cellParams());grid.addView(label("Sat",12f,muted,true),cellParams());executor.execute{try{val m=ApiClient.month(calYear,calMonth);val days=ApiClient.parseDays(m);runOnUiThread{currentDays=days;renderCalendar(grid,days)}}catch(e:Exception){runOnUiThread{toast("Unable to load this month")}}}}
 private fun cellParams()=GridLayout.LayoutParams().apply{width=0;height=74;columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(2,2,2,2)}
 private fun renderCalendar(grid:GridLayout,days:List<DayInfo>){while(grid.childCount>7)grid.removeViewAt(7);val first=days.firstOrNull()?.adDay?.toIntOrNull()?:1; // API's first day is always month day; derive weekday from AD conversion
  executor.execute{try{val ad=ApiClient.bsToAd(calYear,calMonth,1).getJSONObject("ad");val date=ad.optString("date");val parsed=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date);val cal=Calendar.getInstance().apply{time=parsed?:Date()};val wd=cal.get(Calendar.DAY_OF_WEEK);val offset=wd-1;runOnUiThread{for(i in 0 until offset)addBlank(grid);days.forEach{d->addDay(grid,d)} }}catch(_:Exception){runOnUiThread{days.forEach{addDay(grid,it)}}}}
 }
 private fun addBlank(grid:GridLayout){grid.addView(TextView(this),cellParams())}
 private fun addDay(grid:GridLayout,d:DayInfo){val c=card().apply{radius=16f;setCardBackgroundColor(if(d.holiday)Color.rgb(70,45,43) else surface);setOnClickListener{showDay(d)}};val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;setPadding(3,5,3,5)};b.addView(label(d.nepaliNumber.ifBlank{"${d.bsDay}"},20f,if(d.holiday)ContextCompat.getColor(this,R.color.red) else white,true).apply{gravity=Gravity.CENTER});b.addView(label(d.adDay,11f,muted).apply{gravity=Gravity.CENTER});if(d.festival.isNotBlank())b.addView(label("•",14f,lime,true).apply{gravity=Gravity.CENTER});c.addView(b);val p=cellParams();grid.addView(c,p)}
 private fun showDay(d:DayInfo){val s=buildString{append("${d.bsDay} ${months[calMonth-1]} $calYear\n\n");if(d.adDay.isNotBlank())append("AD day: ${d.adDay}\n");if(d.tithi.isNotBlank())append("Tithi: ${d.tithi}\n");if(d.festival.isNotBlank())append("Festival: ${d.festival}\n");if(d.holiday)append("Public holiday\n")};MaterialAlertDialogBuilder(this).setTitle("Date details").setMessage(s).setPositiveButton("Close",null).show()}
 private fun changeMonth(delta:Int){calMonth+=delta;if(calMonth<1){calMonth=12;calYear--};if(calMonth>12){calMonth=1;calYear++};showCalendar()}
 private fun showFestivals(){title("Festivals & Holidays","Events for BS $calYear");val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};content.addView(box);box.addView(label("Loading live calendar data…",15f,muted));executor.execute{try{val j=ApiClient.year(calYear);val out=mutableListOf<String>();for(m in 1..12){val mo=j.optJSONObject(m.toString())?:continue;for(d in ApiClient.parseDays(mo)){if(d.festival.isNotBlank()||d.holiday)out.add("${d.bsDay} ${months[m-1]} • ${if(d.festival.isNotBlank())d.festival else "Public holiday"}")}};runOnUiThread{box.removeAllViews();if(out.isEmpty())box.addView(label("No festival records returned.",15f,muted)) else out.distinct().forEach{val c=card();c.addView(label(it,15f,white,false).apply{setPadding(16,16,16,16)});box.addView(c);box.addView(Space(this),LinearLayout.LayoutParams(1,7))}}}catch(_:Exception){runOnUiThread{box.removeAllViews();box.addView(label("Could not load festival data. Check your internet connection.",15f,muted))}}}}
 private fun showConverter(){title("Date Converter","Convert between Bikram Sambat and Gregorian");val mode=MaterialButton(this).apply{text="BS → AD"};content.addView(mode);val y=TextInputLayout(this).apply{hint="Year"};val ey=TextInputEditText(this);y.addView(ey);val m=TextInputLayout(this).apply{hint="Month"};val em=TextInputEditText(this);m.addView(em);val d=TextInputLayout(this).apply{hint="Day"};val ed=TextInputEditText(this);d.addView(ed);content.addView(y);content.addView(m);content.addView(d);val go=MaterialButton(this).apply{text="Convert"};content.addView(go);val result=label("",18f,lime,true);content.addView(result);mode.setOnClickListener{mode.text=if(mode.text.toString().startsWith("BS"))"AD → BS" else "BS → AD"};go.setOnClickListener{try{val a=ey.text.toString().toInt();val b=em.text.toString().toInt();val c=ed.text.toString().toInt();val bs=mode.text.toString().startsWith("BS");result.text="Converting…";executor.execute{try{val j=if(bs)ApiClient.bsToAd(a,b,c) else ApiClient.adToBs(a,b,c);val obj=j.getJSONObject(if(bs)"ad" else "bs");val text=if(bs) obj.optString("formatted", "${obj.optInt("year")}-${obj.optInt("month")}-${obj.optInt("day")}") else "${obj.optInt("year")}-${obj.optInt("month")}-${obj.optInt("day")}";runOnUiThread{result.text=text}}catch(_:Exception){runOnUiThread{result.text="Conversion failed"}}}}catch(_:Exception){result.text="Enter valid numbers"}}}
 private fun showMore(){title("More","App and personal tools");val about=card();val ab=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18)};ab.addView(label("Nepali Calendar",22f,white,true));ab.addView(label("A modern Bikram Sambat calendar",14f,muted));ab.addView(label("Developer: Rajeshwor Maharjan",15f,lime,true));ab.addView(label("Version 1.0.0",13f,muted));about.addView(ab);content.addView(about);content.addView(Space(this),LinearLayout.LayoutParams(1,12));val events=card();val eb=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(18,18,18,18)};eb.addView(label("Personal events",20f,white,true));eb.addView(label("Store birthdays, anniversaries and reminders on this device.",13f,muted));val add=MaterialButton(this).apply{text="Add event";setOnClickListener{addEventDialog(eb)}};eb.addView(add);content.addView(events);events.addView(eb);renderSavedEvents(eb)}
 private fun addEventDialog(parent:LinearLayout){val input=TextInputLayout(this).apply{hint="Event name"};val e=TextInputEditText(this);input.addView(e);MaterialAlertDialogBuilder(this).setTitle("New event").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_->val s=e.text.toString().trim();if(s.isNotEmpty()){getPreferences(0).edit().putStringSet("events",getPreferences(0).getStringSet("events",emptySet())!!.plus(s)).apply();renderSavedEvents(parent)}}.show()}
 private fun renderSavedEvents(parent:LinearLayout){parent.findViewWithTag<View>("saved")?.let{parent.removeView(it)};val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;tag="saved"};val set=getPreferences(0).getStringSet("events",emptySet())?:emptySet();if(set.isEmpty())box.addView(label("No personal events yet.",13f,muted)) else set.forEach{s->box.addView(label("• $s",15f,white))};parent.addView(box)}
 private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
