package com.rajeshwor.nepalicalendar

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(24,37,29)
    private val lime = Color.rgb(183,255,114)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); splash() }
    private fun splash() {
        val root = LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.gravity=Gravity.CENTER; root.setBackgroundColor(bg)
        val title=TextView(this); title.text="Nepali Calendar"; title.textSize=30f; title.setTextColor(lime); title.typeface=Typeface.DEFAULT_BOLD; title.gravity=Gravity.CENTER
        val by=TextView(this); by.text="by Rajeshwor Maharjan"; by.textSize=16f; by.setTextColor(Color.WHITE); by.gravity=Gravity.CENTER
        root.addView(title); root.addView(by); setContentView(root)
        root.postDelayed({ home() }, 1200)
    }
    private fun home() {
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(28,40,28,20); root.setBackgroundColor(bg)
        fun tv(text:String,size:Float,color:Int,bold:Boolean=false):TextView { val t=TextView(this); t.text=text; t.textSize=size.toFloat(); t.setTextColor(color); if(bold)t.typeface=Typeface.DEFAULT_BOLD; t.setPadding(0,12,0,12); return t }
        root.addView(tv("Nepali Calendar",28,lime,true)); root.addView(tv("Today • Bikram Sambat",15,Color.LTGRAY)); root.addView(tv("2083 Bhadra 30",34,Color.WHITE,true)); root.addView(tv("September 15, 2026",18,Color.LTGRAY)); root.addView(tv("Calendar features coming soon",18,lime,false)); root.addView(tv("Developer: Rajeshwor Maharjan",14,Color.LTGRAY)); setContentView(root)
    }
}
